<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['jwt_key'] = 'MY_SECRET_KEY';