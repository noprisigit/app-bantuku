

            <section class="content">
               <div class="card">
                  <!-- <div class="card-header">
                     <button type="button" data-toggle="modal" data-target="#modal-add" class="btn btn-primary" style="background-image: linear-gradient(to right bottom, #00C6FF, #0072FF)"><i class="fas fa-plus-square"></i> Tambah Kategori</button>
                  </div> -->
                  <div class="card-body">
                     <div class="table-responsive">
                        <table id="transaction" class="table table-bordered table-striped nowrap" width="100%">
                           <thead>
                              <tr>
                                 <th class="text-center">#</th>
                                 <th class="text-center">Nomor Pesanan</th>
                                 <th class="text-center">Nama Produk</th>
                                 <th class="text-center">Nama Toko</th>
                                 <th class="text-center">Jumlah Pesanan</th>
                                 <th class="text-center">Total Bayar</th>
                                 <th class="text-center">Status Pesanan</th>
                                 <th class="text-center">Tanggal Pesanan</th>
                              </tr>
                           </thead>
                           <tbody></tbody>
                           <tfoot>
                              <tr>
                                 <th class="text-center">#</th>
                                 <th class="text-center">Nomor Pesanan</th>
                                 <th class="text-center">Nama Produk</th>
                                 <th class="text-center">Nama Toko</th>
                                 <th class="text-center">Jumlah Pesanan</th>
                                 <th class="text-center">Total Bayar</th>
                                 <th class="text-center">Status Pesanan</th>
                                 <th class="text-center">Tanggal Pesanan</th>
                              </tr>
                           </tfoot>
                        </table>
                     </div>
                  </div>
               </div>
            </section>      